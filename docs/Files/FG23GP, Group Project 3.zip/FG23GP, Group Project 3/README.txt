This text will be referring to the pictures/screenshots that I have left in the folder.

The pictures you’re about to inspect are some of the parts that I considered to be bigger/more important/or simply presented all my work in one place. I have done a ton of other things but wanted to keep my presentation as brief and clean as possible, so I didn’t go around looking for every single piece of code I made. 

The last thing to note is that certain code looks quite messy, unorganized, scattered around everywhere in space. That’s for the sake of me being able to take a proper picture of it, and so u can see it all grouped together in one picture. I later reverted the code to a cleaner and more readable state than it had in the first place. So please forgive me for showing some unorganized stuff, I promise the final build didn’t look like that!
